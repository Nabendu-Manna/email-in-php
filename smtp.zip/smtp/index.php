<?php
require 'PHPMailerAutoload.php';

$con=mysqli_connect("localhost","root","","blog");
if(isset($_POST['submit'])){
    $smail = $_POST['smail'];
    $rmail = $_POST['rmail'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];

    $mail = new PHPMailer;
    $mail->isSMTP();
    $mail->Host='smtp.gmail.com';
    $mail->Port=587;
    $mail->SMTPAuth=true;
    $mail->SMTPSecure='tls';

    $mail->Username='email@gmail.com';
    $mail->Password='**************';

    $mail->setFrom($smail, 'Nabendu');
    $mail->addAddress($rmail);
    $mail->addReplyTo($smail);

    $mail->isHTML(true);
    $mail->Subject=$subject;
    $mail->Body="<center><h1>$body</h1></center> <br><br><hr> <center><h5>Mr.Nanna</h5></center>";
    if(!$mail->send()){
        echo"<script>alert('Mail not sent!')</script>";
    }else{
        echo"<script>alert('Mail sent.')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="include/main.css">
  <title>Nabendu Manna</title>
</head>
<body>
<div class="container">
  <div class="row">
  	<div class="col-lg-12">
  		<div class="box-element product">
          <center><h2>Nabendu mail</h2></center>
  		</div>
    </div>
  </div><br><hr>

  <div class="row">
    	<div class="col-lg-12">
    		<div class="box-element product">
        <form action="index.php" method="post" enctype="multipart/form-data">
                <div class = "form-group row">
                    <label for = "staticEmail" class = "col-2 col-form-label"><center>Sender email</center></label>
                    <div class = "col-10">
                        <input type="email"  class="form-control" id="exampleFormControlInput1" placeholder="name@example.com" name="smail" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputPassword" class="col-2 col-form-label"><center>Receiver email</center></label>
                    <div class="col-10">
                        <input type="email"  class="form-control" id="inputPassword" placeholder="name@example.com" name="rmail" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputPassword" class="col-2 col-form-label"><center>Subject</center></label>
                    <div class="col-10">
                        <input type="text"  class="form-control" id="inputPassword" placeholder="subject" name="subject" required>
                    </div>
                </div>
                <div class="form-group row">
                    <label for="inputPassword" class="col-2 col-form-label"><center>Body</center></label>
                    <div class="col-10">
                        <input type="text"  class="form-control" id="inputPassword" placeholder="body" name="body" required>
                    </div>
                </div>
                <div class="form-group row">
                    <div class="col-12"><hr>
                        <center><input type="submit" class="btn btn-primary mb-2" value="Submit" name="submit"></center>
                    </div>
                </div>
          </form>
    		</div>
      </div>
    </div>
</div>
<!-- 
<form action="index.php" method="post" enctype="multipart/form-data">
	<input type="email" name="smail" required="" placeholder="Enter sender email">
  <input type="email" name="rmail" required="" placeholder="">
  <input type="text" name="subject" required="" placeholder="Subject">
  <input type="text" name="body" required="" placeholder="">
	<input type="submit" name="submit" value="Submit">
</form> -->

<!-- JS, Popper.js, and jQuery -->
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js" integrity="sha384-OgVRvuATP1z7JjHLkuOU7Xw704+h835Lr+6QL9UvYjZE3Ipu6Tp75j7Bh/kR0JKI" crossorigin="anonymous"></script>

</body>

</html>